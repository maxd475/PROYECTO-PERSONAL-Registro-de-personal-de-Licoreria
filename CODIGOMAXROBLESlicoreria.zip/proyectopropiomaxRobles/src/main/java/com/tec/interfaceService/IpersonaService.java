package com.tec.interfaceService;

import java.util.List;
import java.util.Optional;

import com.tec.modelo.persona;

public interface IpersonaService {

	public List<persona> listar();
	public Optional<persona>listarId(int id);
	public int save(persona p);
	public void delete(int id);
	 
}
